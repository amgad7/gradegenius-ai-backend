# GradeGenius Model and Dataset Explanation

## What model does the app use?

The current app sends essays to a custom backend hosted on Hugging Face Spaces:

`https://gradegenius-yourname-gradegenius-backend.hf.space`

The backend exposes this API endpoint:

`POST /grade`

The Flutter app calls this backend and receives the grading result as JSON.

The app does not train a local AI model. There is no local `.h5`, `.pkl`, `.pt`,
`.onnx`, or `.tflite` model file in this project.

Inside this repository, the backend/model code is stored in:

- `ai_backend/model/essay_grader.py`
- `ai_backend/server.py`
- `ai_backend/evaluate_model.py`
- `ai_backend/requirements.txt`

So if someone asks for the "model code", send the `ai_backend` folder.

## Where is the model configured?

The model/backend integration is configured in the Flutter code here:

- `lib/core/constants/app_constants.dart`
  - `customBackendUrl`
  - Hugging Face backend URL

- `lib/core/network/api_client.dart`
  - Creates `customInstance`
  - Uses `customBackendUrl` as the API base URL

- `lib/features/essay_grading/data/datasources/essay_remote_data_source.dart`
  - `EssayRemoteDataSourceCustom`
  - Sends the essay to `POST /grade`
  - Parses the JSON response
  - Falls back to mock analysis if the API fails

If the supervisor asks for the "model file", the accurate answer is:

> The mobile app does not contain a local model weight file. It calls a backend
> hosted on Hugging Face Spaces. The editable model/backend files are in the
> `ai_backend` folder / Hugging Face Space repository, while the Flutter app
> contains the API connection code.

## What is the Hugging Face docs link?

The Swagger/OpenAPI link:

`https://gradegenius-yourname-gradegenius-backend.hf.space/docs#/default/grade_grade_post`

is the documentation page for the backend API.

It shows that the backend has a `POST /grade` endpoint. This endpoint receives
essay text from the app and returns the analysis result.

In simple words:

> Hugging Face hosts the backend/model service. Flutter is the user interface.
> The dataset is used to test the output.

## What does the custom model code do?

The custom backend uses a rule-based NLP model:

- spelling correction dictionary
- category keyword classifier
- vocabulary suggestion dictionary
- statistical score based on length, lexical diversity, word complexity,
  academic word density, sentence structure, and spelling penalties

The main editable model file is:

`ai_backend/model/essay_grader.py`

The FastAPI file that exposes the model as an API is:

`ai_backend/server.py`

If spelling mistakes do not appear in the app, check these points:

1. The Hugging Face Space must be running the latest `ai_backend` code.
2. The app must call `POST /grade` successfully.
3. The typed wrong word must exist in the model's spelling correction
   dictionary, or the dictionary must be expanded.

## What dataset is used?

The project dataset is:

`datasets/essay_correction_evaluation.csv`

This dataset contains labeled essay examples used for evaluation and testing.
It includes:

- essay text
- expected wrong words
- expected corrections
- expected essay category
- expected vocabulary improvements
- notes for evaluation

## Is the dataset used for training?

No. The dataset is not used inside the Flutter app to train a model.

The dataset is used to test and validate the app/backend output.

The correct explanation is:

> The dataset is an evaluation dataset. I use it to compare the app result with
> expected results for spelling correction, category detection, and vocabulary
> suggestions.

## How is the dataset tested?

Manual testing:

1. Open `datasets/dataset_viewer.html`.
2. Choose a row from the dataset.
3. Copy the `essay_text`.
4. Paste it into the app.
5. Compare the app result with the expected columns.

Automated testing:

Run:

```bash
dart run tools/evaluate_dataset.dart
```

The script reads:

`datasets/essay_correction_evaluation.csv`

Then it sends each essay to the grading API and writes:

- `datasets/evaluation_results.csv`
- `datasets/evaluation_summary.md`

## Short answer for discussion

> The Flutter app calls a grading backend hosted on Hugging Face Spaces. The API
> endpoint is `POST /grade`. There is no local model file inside the Flutter
> project. The dataset is used for evaluation, not training. It helps test
> spelling correction, essay category detection, and vocabulary suggestions.
